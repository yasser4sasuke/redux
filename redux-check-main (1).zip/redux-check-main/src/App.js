import react from "react";
import "./App.css";
import TodoApp from "./Component/TodoApp/TodoApp";

function App() {
  return (
    <div>
      <TodoApp />
    </div>
  );
}

export default App;